public class Rubber extends Duck {
    public void display(){
        System.out.println("This is a Rubber Duck");
    }
}
