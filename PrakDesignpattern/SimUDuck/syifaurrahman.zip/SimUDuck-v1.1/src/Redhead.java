public class Redhead extends Duck {
    public void display(){
        System.out.println("This is a Read Head Duck");
    }
}
