public class Mallar extends Duck {
    public void display(){
        System.out.println("This is a Mallar Duck");
    }
}
